const express = require('express');
const cors = require('cors');
const mysql = require('mysql');
const { json } = require('express');



const app = express();
app.use(cors())

app.use(express.urlencoded({ extended: false }))
app.use(express(json));

//plantillasc con ejs para mostrar la información
app.set('view engine', 'ejs');

// conectamos con router.js
app.use('/', require('./router'));

// escuchamos peticiones al server por el puerto 3002
app.listen(3002, () => {
    console.log('Servidor arriba!')
});