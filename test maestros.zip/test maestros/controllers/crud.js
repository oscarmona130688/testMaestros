const conexion = require('../database/db');

exports.save = (req, res) => {
    const cedula = req.body.cedula;
    const nombre = req.body.nombre;
    const telefono = req.body.telefono;
    const direccion = req.body.direccion;
    //console.log(cedula + "-" + nombre + "-" + telefono + "-" + direccion);
    conexion.query('INSERT INTO maestros set ?', { cedula: cedula, nombre: nombre, telefono: telefono, direccion: direccion }, (error, results) => {
        if (error) {
            throw error;
        } else {
            res.redirect('/');
        }
    });
}