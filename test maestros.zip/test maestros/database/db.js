const mysql = require('mysql');
//creamos nuesta conexión a la base de datos mysql
var conexion = mysql.createConnection({
    host: 'localhost',
    database: 'prueba',
    user: 'oscar',
    password: '130688'


});

conexion.connect(function (error) {
    if (error) {
        throw error;
    } else {
        console.log('conexion al a base de datos exitosa¡');
    }
});

//conexion.end();

module.exports = conexion;